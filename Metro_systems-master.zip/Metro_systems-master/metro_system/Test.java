
public class Test {
public static void main(String[] args) {
		
		System.out.println("hello there");
			System.out.println("i think its time we should do our first commit");

	}
}
